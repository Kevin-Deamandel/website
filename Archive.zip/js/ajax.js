// JavaScript Document
$(document).ready(function(){

   // jQuery methods go here..
   
	//$('#content').load('ajax/contact.html #container');
	$("#contact").click(function() {
		$('#content').load('ajax/contact.html #container');});
});
